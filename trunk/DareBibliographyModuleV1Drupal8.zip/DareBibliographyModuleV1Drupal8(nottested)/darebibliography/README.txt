1.Copy this Folder to your module directory
2.Replace the "bibliography.xml" file with your "bibliography.xml" file
3.Activate the Module on your Drupal Page 
4.You can open your module at url/darebibliography

Optional:
If you change the name of the "bibliography.xml" file, you have to change it in darebibliography.module file (line 44), too.
  